const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();
const PORT = 3000;
app.use(cors());
app.use(bodyParser.json());
app.get('/', (req, res) => {
    res.send('Hello from Express!');
});

    
app.post('/updateData', (req, res) => {
    const newData = req.body;

    fs.readFile('src/assets/data.json', 'utf8', (readErr, data) => {
        if (readErr) {
            console.error(readErr);
            res.status(500).json({ error: 'Error reading file', details: readErr.message });
            return;
        }

        let existingData;

        try {
            existingData = JSON.parse(data);
        } catch (parseErr) {
            console.error(parseErr);
            res.status(500).json({ error: 'Error parsing JSON', details: parseErr.message });
            return;
        }

        if (!Array.isArray(existingData)) {
            
            existingData = [];
        }

        const existingDateIndex = existingData.findIndex(entry => entry.date === newData.date);

        if (existingDateIndex !== -1) {
          existingData[existingDateIndex].tasks.push(...newData.tasks.flat());
        } else {
            existingData.push({
                date: newData.date,
                tasks: newData.tasks.flat()
            });
        }

        fs.writeFile('src/assets/data.json', JSON.stringify(existingData), (writeErr) => {
            if (writeErr) {
                console.error(writeErr);
                res.status(500).json({ error: 'Error writing to file', details: writeErr.message });
            } else {
                console.log('Data written to file');
                res.status(200).json({ message: 'Data written to file' });
            }
        });
    });
});
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
